
//MOSTRAR Y OCULTAR EL CARRITO 
const btncarrito = document.querySelector('.container');
const containercartproduct = document.querySelector('.container-cart-product');

btncarrito.addEventListener('click', () => {
    containercartproduct.classList.toggle('hidden-cart')
})

////////////////***************************/////////////////

//CONSTANTES
const carinfo = document.querySelector('.cart-product');
const rowproduct = document.querySelector('.row-product');

//LISTA DE TODOS LOS PRODUCTOS
const productlist = document.querySelector('.container-items')

//ARREGLO DE LOS PRODUCTOS
let todoslosproductos = [];



const subtotal = document.querySelector('.subtotal');
const contador = document.querySelector('#contador-product')
const cartEmpty = document.querySelector('.cart-empty');
const cartTotal = document.querySelector('.cart-total');

const btncomprar = document.querySelector('.btncomprar')


////////////////------FUNCIONES--------/////////////////

productlist.addEventListener('click', e => {

    if (e.target.classList.contains('carrito')) {
        const product = e.target.parentElement;

        const infoproduct = {
            cantidad: 1,
            titulo: product.querySelector('h4').textContent,
            precio: product.querySelector('p').textContent

        }

        const valida = todoslosproductos.some(product => product.titulo === infoproduct.titulo)

        if (valida) {
            const products = todoslosproductos.map(product => {
                if (product.titulo === infoproduct.titulo) {
                    product.cantidad++;
                    return product
                }
                else {
                    return product
                }
            })
            todoslosproductos = [...products]
        }
        else {
            todoslosproductos = [...todoslosproductos, infoproduct];

        }

        mostrar();

        console.log(valida)
        console.log(todoslosproductos)
        console.log(infoproduct)
        console.log(product.querySelector('h4'));
        console.log(product.querySelector('.precio').textContent)

        document.querySelector('.boton-comprar').style.display = "block"
    }
})


//ELIMINA EL ARTICULO QUE ESTE EN EL CARRITO
rowproduct.addEventListener('click', (e) => {
    if (e.target.classList.contains('icon-close')) {
        const product = e.target.parentElement
        const titulo = product.querySelector('p').textContent
        todoslosproductos = todoslosproductos.filter(product => product.titulo !== titulo)

        mostrar();

        console.log(todoslosproductos);
        console.log(rowproduct)
        console.log(product)

    }
})


//MOSTRAR PRODUCTOS EN HTML
const mostrar = () => {

    if (!todoslosproductos.length) {
        cartEmpty.classList.remove('hidden');
        rowproduct.classList.add('hidden');
        cartTotal.classList.add('hidden');
    } else {
        cartEmpty.classList.add('hidden');
        rowproduct.classList.remove('hidden');
        cartTotal.classList.remove('hidden');
    }

    rowproduct.innerHTML = '';

    let total = 0;
    let totaldeproductos = 0;

    todoslosproductos.forEach(product => {
        const containerproduct = document.createElement('div')
        containerproduct.classList.add('cart-product')

        containerproduct.innerHTML =
            `
            <div class="info-cart-product">
            <span class="cantidad-producto-carrito">${product.cantidad}</span>
            <p class="titulo-producto-carrito">${product.titulo}</p>
              <span class="precio-carrito-producto">${product.precio}</span>
            </div>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                stroke-width="1.5" stroke="currentColor" class="icon-close">
                <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>

            `

        rowproduct.append(containerproduct);

        // AQUI SE ACTUALIZA EL CARRIT0 CADA VEZ QUE DOY CLICK
        total = total + parseInt(product.cantidad * product.precio.slice(1))
        totaldeproductos = totaldeproductos + product.cantidad;


    })
      
    if (totaldeproductos <= 0) 
    {
        document.querySelector('.boton-comprar').style.display = "none"
    }

    subtotal.innerText = `¢${total}`
    contador.innerText = totaldeproductos;

}



//ESTO HACE QUE SALGA UN MENSAJE AL DARLE FINALIZAR COMPRA
function compra() {
    document.getElementById('alerta-compra').style.display = "block";
    let cerrar = document.querySelector('.cerrar');
    todoslosproductos=[];
    containercartproduct.classList.toggle('hidden-cart');

    mostrar();

    cerrar.addEventListener('click', () => {
        document.querySelector('.msg-compra').style.display = "none";
    })
}





