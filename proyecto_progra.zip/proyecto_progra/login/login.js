
const btn = document.querySelector('#btn-log');
const pass = document.getElementById('pass');

btn.addEventListener('click', ()=>{

   if (pass.value != "1234")
    {
      alert("Usuario o contraseña incorrecta!")
  } 
  else {
    location="../html/index.html"
  }

    console.log(input)

});

